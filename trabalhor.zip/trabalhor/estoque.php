<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Estoque</title>
</head>
<body>
<div id="wrapper">

<ul class="navbar-nav bg-gradient-info sidebar sidebar-dark accordion" id="accordionSidebar">

    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="testando2.php">
        <div class="sidebar-brand-icon rotate-n-15">
        <i class='fa fa-car'></i>
        </div>
        <div class="sidebar-brand-text mx-3">teste</div>
    </a>

    <hr class="sidebar-divider my-0">

    <li class="nav-item">
        <a class="nav-link" href="testando2.php">
            <i class="fas fa-solid fa-list"></i>
            <span>Tela Inicial</span></a>
    </li>
    <hr class="sidebar-divider">
    <hr class="sidebar-divider d-none d-md-block">

    <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

        </ul>
        <div id="content-wrapper" class="d-flex flex-column">

            <div id="content">
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item dropdown no-arrow d-sm-none">
                            <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-search fa-fw"></i>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in"
                                aria-labelledby="searchDropdown">
                                <form class="form-inline mr-auto w-100 navbar-search">
                                    <div class="input-group">
                                        <input type="text" class="form-control bg-light border-0 small"
                                            placeholder="Search for..." aria-label="Search"
                                            aria-describedby="basic-addon2">
                                        <div class="input-group-append">
                                            <button class="btn btn-primary" type="button">
                                                <i class="fas fa-search fa-sm"></i>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </li>
                    <div class="topbar-divider d-none d-sm-block"></div>
                    <li class="nav-item dropdown no-arrow">
                        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span class="mr-2 d-none d-lg-inline text-gray-600 small">Admin</span>
                            <img class="img-profile rounded-circle"
                                src="./src/img/undraw_profile.svg">
                        </a>
                        <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                        aria-labelledby="userDropdown">
                        <a class="dropdown-item" href="login.php">
                        <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                            Sair
                        </a>
                    </div>
                </li>

            </ul>
        </nav>
        <div class="container-fluid">

            <h1 class="h3 mb-4 text-gray-800">Estoque</h1>
            <?php

    include './private/connect.php';
    include './template/header.php';
    $txtSubmit = (isset($_GET['id']))? 'Editar' : 'Cadastrar';
    if(isset($_GET['id'])){
        $sqlQuery = "SELECT * FROM produtos WHERE id='{$_GET['id']}'";
        if($result = mysqli_query($mysqli, $sqlQuery)){
            $row = mysqli_fetch_assoc($result);
        }
    }

    if(isset($_POST['id'])){
        if($_POST['id'] != ''){
            
        $sqlUp = "UPDATE produtos SET nome=?, descricao=?, quantidade=?, marca=? WHERE id={$_POST['id']}";
        $stmt = $mysqli->prepare($sqlUp);
        if(!$stmt){
            echo 'Erro: ' . $mysqli->error;
        }
        $stmt->bind_param('ssss', $_POST['nome'], $_POST['descricao'], $_POST['quantidade'], $_POST['marca']);
        $stmt->execute();
        } else {

            $sqlIns = "INSERT INTO produtos (nome, descricao, quantidade, marca) VALUES (?, ?, ?, ?)";
            $stmt = $mysqli->prepare($sqlIns);
            if(!$stmt){
                echo 'Erro: ' . $mysqli->error;
            }
            $stmt->bind_param('ssss', $_POST['nome'], $_POST['descricao'], $_POST['quantidade'], $_POST['marca']);
            $stmt->execute();
        }
    }
?>

    <br>
    <table class="table">
        <thead>
            <tr>
                <th>Nome</th>
                <th>Quantidade</th>
                <th>Descrição</th>
                <th>Marca</th>
                <th>#</th>
            </tr>
        </thead>
        <tbody>
            <?php 
                $sql = "SELECT * FROM produtos";
                if($result = mysqli_query($mysqli, $sql)){
                    while($rows = mysqli_fetch_array($result)){
                      echo "<tr>
                                <td>{$rows['nome']}</td>
                                <td>{$rows['quantidade']}</td>
                                <td>{$rows['descricao']}</td>
                                <td>{$rows['marca']}</td>
                                </td>
                            </tr>";
                    }
                    mysqli_free_result($result);
                }
            ?>
        </tbody>
    </table>
    </div>
</div>
</div>
<a class="scroll-to-top rounded" href="#page-top">
<i class="fas fa-angle-up"></i>
</a>
</div>
</div>
<?php include './layout/footer.php'; ?>
</div>
</body>
</html>