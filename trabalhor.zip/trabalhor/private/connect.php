<?php
    $host = "localhost";
    $user = "root";
    $password = "";
    $database = "estagio";

    $mysqli = mysqli_connect($host, $user, $password, $database);
    if(mysqli_connect_errno($mysqli)){
        echo "Failed to connect to MySQL: " . mysqli_connect_errno();
    }
?>