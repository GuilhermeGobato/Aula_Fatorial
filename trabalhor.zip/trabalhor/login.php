<?php
include './private/connect.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Área de Login</title>
</head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<body>
    <br><br>
<div class="px-6 py-7 px-md-7 text-center text-lg-start" style="background-color: hsl(0, 0%, 100%)">
    <div class="container-fluid">
    <div class="row gx-lg-1 align-items-center">
        <div class="col-lg-1 mb-1 mb-lg-0">
        <img src="./img/fundo.png" width="580" height="720">
        </div>

        <div class="col-lg-5 mb-4 mb-lg-0">
          <div class="card">
            <div class="card-body py-5 px-md-5">
              <form>
                <div class="row">
                  <div class="col-md-6 mb-4">
                    <div class="form-outline">
                    <label class="form-label" for="form3Example1">Usuario</label>
                      <input type="text" id="user" class="form-control" />
                    </div>
                  </div>
                  <div class="col-md-6 mb-4">
                    <div class="form-outline">
                    <label class="form-label" for="form3Example2">Senha</label>
                      <input type="password" id="senha" class="form-control" />
                    </div>
                  </div>
                </div>
                <!--<input style="margin: 0 145px;" type='button' value='Acessar'><input style="margin: 0 -120px;" type='button' value='Sair'>-->
                <input type="submit" class="sb bradius" value="Entrar">
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</body>
</html>