<?php

    if($_POST['email'] == 'diogo@digitalone.com.br'){
        session_start();
        $_SESSION['user'] = $_POST['email'];
        echo 'login efetuado com sucesso';
    } else {
        echo 'usuario ou senha invalido';
    }

?>